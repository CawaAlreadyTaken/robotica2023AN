var searchData=
[
  ['pick_5fand_5fplace_0',['pick_and_place',['../assignment1_8cpp.html#aa1e7e1b8214d657b67c8f72b98460223',1,'pick_and_place(Vector3d pick, Vector3d place, bool go_super_low=false):&#160;assignment1.cpp'],['../assignment2_8cpp.html#aa1e7e1b8214d657b67c8f72b98460223',1,'pick_and_place(Vector3d pick, Vector3d place, bool go_super_low=false):&#160;assignment2.cpp'],['../assignment3_8cpp.html#af7fd514ddae52174a71353fa5aa21fe5',1,'pick_and_place(Vector3d pick, Vector3d place, bool second_block, bool go_super_low=false):&#160;assignment3.cpp'],['../assignment4_8cpp.html#a8f4c8e07d2dce7acaf397f958202a22b',1,'pick_and_place(Vector3d pick, Vector3d place, bool ultimo=false):&#160;assignment4.cpp']]],
  ['position_5fon_5fblock_5ffor_5frotation_5fworld_1',['POSITION_ON_BLOCK_FOR_ROTATION_WORLD',['../custom__joint__publisher_8h.html#a1a4237214ec83d360f2cb18b6ee4c3c4',1,'custom_joint_publisher.h']]],
  ['positioned_2',['positioned',['../assignment3_8cpp.html#a6f9b6dbd55d687333b89ea7674de0048',1,'assignment3.cpp']]],
  ['print_5fmatrix_3',['print_matrix',['../path__finding_8cpp.html#adb3e30c416cab834aef991b0daff4660',1,'path_finding.cpp']]]
];
