var searchData=
[
  ['template_5fmatching_0',['template_matching',['../classvision_node_1_1_vision_node.html#a33b08c33066d21a5aed2877afb71d354',1,'visionNode::VisionNode']]],
  ['test_5frandom_5fangles_1',['test_random_angles',['../difftest_8cpp.html#afab94ec93b847c96e96ce513e82c1e22',1,'difftest.cpp']]],
  ['test_5fstandard_5fangles_2',['test_standard_angles',['../difftest_8cpp.html#aaf9bff51660e7021b955e51357f66331',1,'difftest.cpp']]],
  ['trapezoidal_5fvelocity_3',['trapezoidal_velocity',['../class_differential_kinematic.html#a13303bf1720904a67d616676d6273876',1,'DifferentialKinematic::trapezoidal_velocity()'],['../path__finding_8h.html#abb4007979f622e9061c0c87645c069b1',1,'trapezoidal_velocity(Vector3d pi, Vector3d pf, double t):&#160;path_finding.cpp'],['../path__finding_8cpp.html#abb4007979f622e9061c0c87645c069b1',1,'trapezoidal_velocity(Vector3d pi, Vector3d pf, double t):&#160;path_finding.cpp']]]
];
