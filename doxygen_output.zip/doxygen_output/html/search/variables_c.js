var searchData=
[
  ['max_5fx_0',['MAX_X',['../namespaceimg_gen__new.html#ae4843ef7b3e730747031ce6d14c03e35',1,'imgGen_new']]],
  ['max_5fy_1',['MAX_Y',['../namespaceimg_gen__new.html#a89f7d4c07bfea84ec7d1a8d0e5af0f22',1,'imgGen_new']]],
  ['metrics_2',['metrics',['../namespacetrain.html#a5bea97c18724e1a360edcb0aa31530c9',1,'train']]],
  ['min_5fx_3',['MIN_X',['../namespaceimg_gen__new.html#a5012dd3698a4fe0c87b489f1b80ae380',1,'imgGen_new']]],
  ['min_5fy_4',['MIN_Y',['../namespaceimg_gen__new.html#a84b77f7dd58474e5ca862829cce159d3',1,'imgGen_new']]],
  ['model_5',['model',['../classvision_node_1_1_vision_node.html#ad07f0bc3ef04d1a9e3c64d3c060db8ac',1,'visionNode.VisionNode.model()'],['../namespacetest.html#a8cbf6990387257b37b75a7e1c9bba7aa',1,'test.model()'],['../namespacetrain.html#ac5337f12dca830d17eb1fe9d1ddfac97',1,'train.model()']]],
  ['moved_5fblocks_6',['moved_blocks',['../assignment2_8cpp.html#abe104cdcbf3c815ff01a1cf5dd490d95',1,'assignment2.cpp']]]
];
