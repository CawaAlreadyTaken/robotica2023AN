var searchData=
[
  ['angle_5findex_0',['angle_index',['../namespaceimg_gen__new.html#a5e75e6d24db91ed53efedeab94acf7ff',1,'imgGen_new']]],
  ['angle_5fval_1',['angle_val',['../namespaceimg_gen__new.html#ae4c2d64e72b3b6e7d6237d3c82a83d5b',1,'imgGen_new']]]
];
