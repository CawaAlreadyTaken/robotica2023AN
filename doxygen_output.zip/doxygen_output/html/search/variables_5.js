var searchData=
[
  ['else_0',['else',['../namespaceimg_gen__new.html#a183bdd13d28fe92b888dc3de336252c4',1,'imgGen_new']]],
  ['epochs_1',['epochs',['../namespacetrain.html#a02a1285941f9536ac94cf1a3d424ae97',1,'train']]]
];
