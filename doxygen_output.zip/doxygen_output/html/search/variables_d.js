var searchData=
[
  ['n_5fblocks_0',['n_blocks',['../namespaceimg_gen__new.html#ae34b55d8b13e7762254b3b5c03c37346',1,'imgGen_new']]],
  ['name_1',['name',['../namespaceimg_gen__new.html#a9ae5ef37201af9bdd41de1ec2ad7ecbb',1,'imgGen_new']]],
  ['number_5fof_5fclasses_2',['NUMBER_OF_CLASSES',['../custom__joint__publisher_8h.html#ac5602596847f8034daef1270f4a37e54',1,'custom_joint_publisher.h']]]
];
